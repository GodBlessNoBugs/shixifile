package cn.tedu.nybike.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.tedu.nybike.pojo.AgeNumDO;
import cn.tedu.nybike.util.HiveDBUtil;

public class AgeNumDAO {
	
/**
 * ��ѯ������genderCount�ķ���
 * @return
 */
public List<AgeNumDO> listAgeNum() {
	List<AgeNumDO> list=new ArrayList<>();
	String sql="select * from tb_age_num";
	try(   //�˽Ȿ�����ݿ����
			//Connection conn=DBUtils.getConn();
			//����hive
			Connection conn=HiveDBUtil.getHiveConn();
		PreparedStatement ps=conn.prepareStatement(sql)){
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			AgeNumDO an=new AgeNumDO();
			an.setName(rs.getString("agetype"));
			an.setValue(rs.getInt("num"));
			list.add(an);
			
		}

	}catch (Exception e) {
		e.printStackTrace();
	}
		return list;
}
	
}
