package cn.tedu.nybike.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.tedu.nybike.pojo.FastigiumDO;
import cn.tedu.nybike.util.HiveDBUtil;

public class FastigiumDAO {
	
	public List<FastigiumDO> listFastigium() {
		List<FastigiumDO> list = new ArrayList<>();
		
		String sql = "select * from tb_fastigium";
		
		try (Connection conn = HiveDBUtil.getHiveConn();
			PreparedStatement ps = conn.prepareStatement(sql)){
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				FastigiumDO fDo = new FastigiumDO();
				fDo.setTime(rs.getString("time"));
				fDo.setNum(rs.getInt("num"));
				list.add(fDo);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
}
