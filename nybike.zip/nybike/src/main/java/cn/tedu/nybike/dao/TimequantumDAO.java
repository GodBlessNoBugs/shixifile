package cn.tedu.nybike.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import cn.tedu.nybike.pojo.TimequantumDO;
import cn.tedu.nybike.util.HiveDBUtil;

public class TimequantumDAO {
	public List<TimequantumDO> listTimequantum() throws SQLException{
		List<TimequantumDO> list = new  ArrayList<>();
		String sql = "select * from tb_trip_count";
		try(Connection con = HiveDBUtil.getHiveConn();
				PreparedStatement ps = con.prepareStatement(sql);){
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				TimequantumDO dc = new TimequantumDO();
				dc.setNum(rs.getInt("num"));
				dc.setTimequantumLevel(rs.getInt("timequantumLevel"));
				list.add(dc);
			}
		}catch(Exception e){
			e.printStackTrace();
		}	
		
		return list;
	}	
}
