package cn.tedu.nybike.pojo;
public class ANItem {
	private String name;
	private Integer value;
	public ANItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getValue() {
		return value;
	}

	public void setValue(Integer value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "ANItem [name=" + name + ", value=" + value + "]";
	}
	
	
}
