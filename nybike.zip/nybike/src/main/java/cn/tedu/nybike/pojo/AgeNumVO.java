package cn.tedu.nybike.pojo;

import java.util.List;

public class AgeNumVO {
	private List<ANItem> data;

	public AgeNumVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<ANItem> getData() {
		return data;
	}

	public void setData(List<ANItem> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "AgeNumVO [data=" + data + "]";
	}
	

}
