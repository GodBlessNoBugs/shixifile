package cn.tedu.nybike.pojo;

public class DPItem {
	private String day; //����
	private Integer num; //�˿�����
	public DPItem() {
	}
	
	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public Integer getNum() {
		return num;
	}
	public void setNum(Integer num) {
		this.num = num;
	}
	@Override
	public String toString() {
		return "DPItem [day=" + day + ", num=" + num + "]";
	}
	
}
