package cn.tedu.nybike.pojo;

public class DayPassengerDO {
	private String day;
	private Integer num;
	public DayPassengerDO() {
	}
	
	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public Integer getNum() {
		return num;
	}
	public void setNum(Integer num) {
		this.num = num;
	}
	@Override
	public String toString() {
		return "DayPassengerDO [day=" + day + ", num=" + num + "]";
	}
}
