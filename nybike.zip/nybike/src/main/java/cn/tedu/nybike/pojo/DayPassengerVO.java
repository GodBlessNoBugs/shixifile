package cn.tedu.nybike.pojo;

import java.util.List;

public class DayPassengerVO {
	private List<DPItem> data;

	public DayPassengerVO() {
	}

	public List<DPItem> getData() {
		return data;
	}

	public void setData(List<DPItem> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "DayPassengerVO [data=" + data + "]";
	}
	
}
