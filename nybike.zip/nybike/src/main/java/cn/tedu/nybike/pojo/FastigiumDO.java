package cn.tedu.nybike.pojo;

public class FastigiumDO {
	private String time;
	private Integer num;
	
	public FastigiumDO() {
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	public Integer getNum() {
		return num;
	}
	public void setNum(Integer num) {
		this.num = num;
	}
	@Override
	public String toString() {
		return "FastigiumDO [time=" + time + ", num=" + num + "]";
	}
	
}
