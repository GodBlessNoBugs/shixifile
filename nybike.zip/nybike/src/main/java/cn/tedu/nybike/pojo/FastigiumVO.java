package cn.tedu.nybike.pojo;

import java.util.List;

public class FastigiumVO {
	private List<FGItem> data;

	public FastigiumVO() {
	}

	public List<FGItem> getData() {
		return data;
	}

	public void setData(List<FGItem> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "FastigiumVO [data=" + data + "]";
	}
	
}
