package cn.tedu.nybike.pojo;

public class GCItem {
	private String name; // �Ա�
	private Integer value; // ����
	
	public GCItem() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getValue() {
		return value;
	}

	public void setValue(Integer value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "GCItem [name=" + name + ", value=" + value + "]";
	}
	
}
