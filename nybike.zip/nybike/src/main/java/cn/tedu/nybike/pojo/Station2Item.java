package cn.tedu.nybike.pojo;

public class Station2Item {

	private Integer count;
	private double lng;
	private double lat;
	public Station2Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public double getLng() {
		return lng;
	}
	public void setLng(double lng) {
		this.lng = lng;
	}
	public double getLat() {
		return lat;
	}
	public void setLat(double lat) {
		this.lat = lat;
	}
	@Override
	public String toString() {
		return "Station2Item [count=" + count + ", lng=" + lng + ", lat=" + lat + "]";
	}

	

}
