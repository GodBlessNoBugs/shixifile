package cn.tedu.nybike.pojo;

import java.util.List;

public class Station2VO {
	
	private List<Station2Item> data;

	public Station2VO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<Station2Item> getData() {
		return data;
	}

	public void setData(List<Station2Item> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "Station2VO [data=" + data + "]";
	}

	
	

}
