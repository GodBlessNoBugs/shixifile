package cn.tedu.nybike.pojo;

public class TimequantumDO {
	private int timequantumLevel;//ʱ��μ���
	private int num;            //�ü��������
	
	

	
	
	
	public TimequantumDO() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getTimequantumLevel() {
		return timequantumLevel;
	}
	public void setTimequantumLevel(int timequantumLevel) {
		this.timequantumLevel = timequantumLevel;
	}
	@Override
	public String toString() {
		return "TimequantumDO [name=" + timequantumLevel + ", value=" + num + "]";
	}

	
	
	







	
	
	
	
}
