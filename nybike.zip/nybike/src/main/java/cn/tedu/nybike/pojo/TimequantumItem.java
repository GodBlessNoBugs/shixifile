package cn.tedu.nybike.pojo;

public class TimequantumItem {
	private String name;//ʱ��μ���
	private Integer value;            //�ü��������
	
	

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getValue() {
		return value;
	}
	public void setValue(Integer value) {
		this.value = value;
	}
	@Override
	public String toString() {
		return "TimequantumItem [name=" + name + ", value=" + value + "]";
	}
	public TimequantumItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
	
	
}
