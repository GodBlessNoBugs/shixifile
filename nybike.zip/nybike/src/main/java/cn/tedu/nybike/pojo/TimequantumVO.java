package cn.tedu.nybike.pojo;

import java.util.List;

public class TimequantumVO {
	List<TimequantumItem> data;

	public TimequantumVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<TimequantumItem> getData() {
		return data;
	}

	public void setData(List<TimequantumItem> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "TimequantumVO [data=" + data + "]";
	}


	
	
}
