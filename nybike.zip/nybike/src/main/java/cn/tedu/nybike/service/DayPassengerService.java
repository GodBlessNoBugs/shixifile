package cn.tedu.nybike.service;

import java.util.ArrayList;
import java.util.List;

import cn.tedu.nybike.dao.DayPassengerDAO;
import cn.tedu.nybike.pojo.DPItem;
import cn.tedu.nybike.pojo.DayPassengerDO;
import cn.tedu.nybike.pojo.DayPassengerVO;

public class DayPassengerService {

	DayPassengerDAO dao = new DayPassengerDAO();
	
	public DayPassengerVO findDayPassenger() {
		List<DayPassengerDO> list = dao.listDayPassenger();
		DayPassengerVO vo = new DayPassengerVO();
		List<DPItem> data = new ArrayList<DPItem>(list.size());
		
		for(DayPassengerDO dp:list){
			DPItem item = new DPItem();
			item.setDay(dp.getDay());
			item.setNum(dp.getNum());
			data.add(item);
		}
		vo.setData(data);
		return vo;
	}
}
