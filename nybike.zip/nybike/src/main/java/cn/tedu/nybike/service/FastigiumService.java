package cn.tedu.nybike.service;

import java.util.ArrayList;
import java.util.List;

import cn.tedu.nybike.dao.FastigiumDAO;
import cn.tedu.nybike.pojo.FGItem;
import cn.tedu.nybike.pojo.FastigiumDO;
import cn.tedu.nybike.pojo.FastigiumVO;

public class FastigiumService {

	FastigiumDAO dao = new FastigiumDAO(); 
	
	public FastigiumVO findFastigium() {
		List<FastigiumDO> list = dao.listFastigium();
		FastigiumVO vo = new FastigiumVO();
		List<FGItem> data = new ArrayList<FGItem>(list.size());
		
		for(FastigiumDO fg:list){
			FGItem item = new FGItem();
			item.setTime(fg.getTime());
			item.setNum(fg.getNum());
			data.add(item);
		}
		vo.setData(data);
		return vo;
		
	}
}
