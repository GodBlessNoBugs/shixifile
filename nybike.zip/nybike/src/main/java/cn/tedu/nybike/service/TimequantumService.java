package cn.tedu.nybike.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



import cn.tedu.nybike.dao.TimequantumDAO;

import cn.tedu.nybike.pojo.TimequantumDO;
import cn.tedu.nybike.pojo.TimequantumItem;
import cn.tedu.nybike.pojo.TimequantumVO;

public class TimequantumService {
	private TimequantumDAO dao = new TimequantumDAO();
	public TimequantumVO findTimequantum() throws SQLException{
		List<TimequantumDO> list = dao.listTimequantum();
		TimequantumVO vo = new TimequantumVO();
		List<TimequantumItem> data = new ArrayList<TimequantumItem>(list.size());
		for(TimequantumDO gc:list){
			TimequantumItem item = new TimequantumItem();
			
			item.setValue(gc.getNum());
			String name=gc.getTimequantumLevel()==1?"����ʱ��15��������":gc.getTimequantumLevel()==2?"����ʱ��15��60����":"����ʱ������60����";
//			if(gc.getTimequantumLevel()==1){
//				
//			}
//			if(gc.getTimequantumLevel()==2){
//				legendArr.push("10");
//			}
//			if(gc.getTimequantumLevel()==3){
//				legendArr.push("11");
//			}
			item.setName(name);
			data.add(item);
		}
		vo.setData(data);
		return vo;
	}
	
}
