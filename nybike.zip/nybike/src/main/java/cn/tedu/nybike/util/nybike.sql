-- ����
create database nybikedb;

-- ʹ�ÿ�
use nybikedb;

-- ���� tb_status
create table tb_status(
id int auto_increment,
sid int comment 'վ��id',
nba int comment '���ó���',
nbd int comment '�𻵳���',
nda int comment '����׮��',
ndd int comment '��׮��',
primary key (id)
)default charset utf8;

-- hiveQL

-- ������
create database nybikedb;

-- ʹ�ÿ�
use nybikedb;

-- ������
create table tb_trip_1(
tripduration int,
starttime string,
stoptime string,
start_station_id int,
start_station_name string,
start_station_latitude double,
start_station_longitude double,
end_station_id int,
end_station_name string,
end_station_latitude double,
end_station_longitude double,
bikeid int,
usertype string,
birth_year int,
gender int
)ROW FORMAT DELIMITED FIELDS TERMINATED BY ',';
-- hive������ԭʼ�����ֶεķָ���ʹ�ö��� 

-- ����hdfs�ϵ�����
load data inpath 'hdfs://master:8020/20190601-3.csv' 
overwrite into table tb_trip_1;

create table tb_gender_count(
start_date date, 
gender int, 
num int 
);

insert into 
 tb_gender_count 
select 
 substr(starttime,0,10), gender, 
 count(*) 
from 
 tb_trip_1
group by
 substr(starttime,0,10), gender;




create table tb_temp(
start_date date
);

insert into tb_temp 
select substr(starttime,0,10) from tb_trip_1 limit 1;

<property>
	<name>hive.server2.thrift.port</name>
	<value>10000</value>
</property>
<property>
	<name>hive.server2.thrift.client.user</name>
	<value>root</value>
</property>
<property>
	<name>hive.server2.thrift.client.password</name>
	<value>root</value>
</property>	


<property>
	<name>hadoop.proxyuser.root.hosts</name>
	<value>*</value>
</property>
<property>
	<name>hadoop.proxyuser.root.groups</name>
	<value>*</value>
</property>

hive --service hiveserver2 &


