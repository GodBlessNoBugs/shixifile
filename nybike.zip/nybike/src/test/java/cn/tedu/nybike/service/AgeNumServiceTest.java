package cn.tedu.nybike.service;

import org.junit.Test;

import cn.tedu.nybike.pojo.AgeNumVO;

public class AgeNumServiceTest {
	
	
	AgeNumService service=new AgeNumService();
	
	
	@Test
	public void listAgeNum(){
		AgeNumVO vo=service.findAgeNum();
		System.out.println(vo);
	}
	
}
