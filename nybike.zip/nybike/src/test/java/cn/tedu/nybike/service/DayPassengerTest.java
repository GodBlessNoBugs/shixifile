package cn.tedu.nybike.service;

import org.junit.Test;

import cn.tedu.nybike.pojo.DayPassengerVO;


public class DayPassengerTest {


	DayPassengerService service=new DayPassengerService();
	
	
	@Test
	public void listAgeNum(){
		DayPassengerVO vo=service.findDayPassenger();
		System.out.println(vo);
	}
	
}
