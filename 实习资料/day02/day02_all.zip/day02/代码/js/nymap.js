// 在地图上添加一个marker的方法
// point marker在地图上的位置
// imgUrl Icon使用的图片的url
// iconSize Icon的大小，即可视区域大小
// anchorSize point相对于Icon左上角的偏移量
function addMarker(point,imgUrl,iconSize,anchorSize){  // 创建图标对象   
	var opts={
			anchor: anchorSize,
			imageSize : iconSize // Icon内部图片的大小
				};
	var myIcon = new BMap.Icon(imgUrl,iconSize,opts);
    // 创建标注对象并添加到地图   
    var marker = new BMap.Marker(point, {icon: myIcon});    
    map.addOverlay(marker);    
} 