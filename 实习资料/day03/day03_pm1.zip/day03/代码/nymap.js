function getBikeLevel(nba,nda){
	// nba=0 或 bike和dock都为0 	->	level 0	->红色
	if(nba==0 || (nba+nda)==0){
		return 0;    
	}
	// nba<5	->	level 1	->黄色
	if(nba<5){
		return 1;
	}
	// 可用车指数(abi)=nba/(nba+nda)
	var abi=nba/(nba+nda); // number
	// abi<0.5	->	level 2	->少绿
	if(abi<0.5){
		return 2;
	}
	// 0.5<= abi <1	->	level 3	->多绿
	if(abi>=0.5 && abi<1){
		return 3;
	}
	// abi=1	->	level 4	->全绿
	if(abi==1){
		return 4;
	}
}



// 在地图上添加一个marker的方法
// point marker在地图上的位置
// imgUrl Icon使用的图片的url
// iconSize Icon的大小，即可视区域大小
// anchorSize point相对于Icon左上角的偏移量
function addMarker(point,imgUrl,iconSize,anchorSize){  // 创建图标对象   
	var opts={
			anchor: anchorSize,
			imageSize : iconSize // Icon内部图片的大小
				};
	var myIcon = new BMap.Icon(imgUrl,iconSize,opts);
    // 创建标注对象并添加到地图   
    var marker = new BMap.Marker(point, {icon: myIcon});    
    map.addOverlay(marker);    
} 