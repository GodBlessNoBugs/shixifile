function switchIcon(isBigIcon){ // isBigIcon代表当前应该使用什么图标
	// 遍历markerArr
	for(var index in markerArr){
		// 获取marker的icon的imageUrl
		var imageUrl=markerArr[index].getIcon().imageUrl;
		// 声明2个临时变量
		var iconSize;
		var anchorSize;
		// 针对当前应该使用的图标类型，获取对应的imageUrl，iconSize和anchorSize
		if(isBigIcon == true){
			imageUrl=imageUrl.replace(/s/,"b");
			iconSize=bigIconSize;
			anchorSize=bigAnchorSize;
		}
		if(isBigIcon == false){
			imageUrl=imageUrl.replace(/b/,"s");
			iconSize=smallIconSize;
			anchorSize=smallAnchorSize;
		}
		// 创建新的Icon
		var opts={
				anchor: anchorSize,
				imageSize : iconSize // Icon内部图片的大小
					};
		var myIcon = new BMap.Icon(imageUrl,iconSize,opts);
	   
		// 调用Marker的setIcon方法，设置新的Icon
		markerArr[index].setIcon(myIcon);
	}
}




function getBikeLevel(nba,nda){
	// nba=0 或 bike和dock都为0 	->	level 0	->红色
	if(nba==0 || (nba+nda)==0){
		return 0;    
	}
	// nba<5	->	level 1	->黄色
	if(nba<5){
		return 1;
	}
	// 可用车指数(abi)=nba/(nba+nda)
	var abi=nba/(nba+nda); // number
	// abi<0.5	->	level 2	->少绿
	if(abi<0.5){
		return 2;
	}
	// 0.5<= abi <1	->	level 3	->多绿
	if(abi>=0.5 && abi<1){
		return 3;
	}
	// abi=1	->	level 4	->全绿
	if(abi==1){
		return 4;
	}
}

// 为一个marker添加单击事件，弹出信息窗
function addMarkerInfoWindow(marker){
	
    var sContent="<div class='mapbox-content'>"+
		"<div class='mapbox-content-top'>"+
			"<span class='window_lastUpdate'> 0 ms ago </span> " +
			"<span class='window_info_button'></span>"+
		"</div>"+
		"<div class='mapbox-content-header'>"+
			"<h1 class='mapbox-content-header-stationName'>info_stationName</h1>"+
		"</div>"+
		"<div class='mapbox-content-detail'>"+
			"<div class='mapbox-content-detail-bikes-available'>"+
				"<span class='mapbox-content-detail-bikes-available-val'> 20 </span>"+
				"<span class='mapbox-content-detail-bikes-available-lbl'>Bikes</span>"+
			"</div>"+
			"<div class='mapbox-content-detail-docks-available'>"+
				"<span class='mapbox-content-detail-docks-available-val'> 6 </span> " +
				"<span class='mapbox-content-detail-docks-available-lbl'>Docks</span>" +
			"</div>"+
		"</div>"+
		"<div class='mapbox-content-footer'>"+
			"<span class='mapbox-content-footer-shortName'> Bike station:"+
				"info_shortName </span>"+
		"</div>"+
	"</div>";
    
    var infoWindow=new BMap.InfoWindow(sContent);
    
    marker.addEventListener("click", function(){          
		this.openInfoWindow(infoWindow);
	});
	
}



// 在地图上添加一个marker的方法
// point marker在地图上的位置
// imgUrl Icon使用的图片的url
// iconSize Icon的大小，即可视区域大小
// anchorSize point相对于Icon左上角的偏移量
function addMarker(point,imgUrl,iconSize,anchorSize){  // 创建图标对象   
	var opts={
			anchor: anchorSize,
			imageSize : iconSize // Icon内部图片的大小
				};
	var myIcon = new BMap.Icon(imgUrl,iconSize,opts);
    // 创建标注对象并添加到地图   
    var marker = new BMap.Marker(point, {icon: myIcon});    
    // 将marker对象添加到marker的数组中
    markerArr.push(marker);
    
    // 调用方法为marker添加信息窗
    addMarkerInfoWindow(marker);
    
    map.addOverlay(marker);    
} 



