package cn.tedu.nybike.test;

import java.util.Iterator;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.tedu.nybike.util.HttpUtil;

public class Test {

	public static void main(String[] args) {
		String statusUrl="https://gbfs.citibikenyc.com/gbfs/en/station_status.json";
		String statusStr=HttpUtil.get(statusUrl);
		JSONObject obj=JSON.parseObject(statusStr);
		JSONObject data=obj.getJSONObject("data");
		JSONArray stations=data.getJSONArray("stations");
		
		Iterator<Object> it=stations.iterator();
		while(it.hasNext()){
			JSONObject jObj=(JSONObject)it.next();
			Integer id=jObj.getInteger("station_id");
			Integer nba=jObj.getInteger("num_bikes_available");
			System.out.println("id="+id+",nba="+nba);
		}
	}

}




