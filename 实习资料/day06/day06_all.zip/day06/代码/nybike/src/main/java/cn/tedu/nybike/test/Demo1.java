package cn.tedu.nybike.test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class Demo1 {

	public static void main(String[] args) {
		// JSON�ַ����л�ȡ����
		String jsonStr="{\"name\":\"Tom\",\"age\":18,"
				+ "\"student\":{\"name\":\"Jerry\",\"age\":20}}";
		// ��json�ַ���ת��Java����
		JSONObject obj=JSON.parseObject(jsonStr);
		/*String name=obj.getString("name");
		Integer age=obj.getInteger("age");
		System.out.println(name);
		System.out.println(age);*/
		JSONObject student=obj.getJSONObject("student");
		System.out.println(student.getString("name"));
	
		// Java���� ���JSON�ַ���
		
	}

}
