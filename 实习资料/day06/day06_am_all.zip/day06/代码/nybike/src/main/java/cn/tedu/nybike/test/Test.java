package cn.tedu.nybike.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.mysql.fabric.xmlrpc.base.Array;

import cn.tedu.nybike.dao.StationDAO;
import cn.tedu.nybike.pojo.StationStatusDO;
import cn.tedu.nybike.util.HttpUtil;

public class Test {

	public static void main(String[] args) {
		String statusUrl="https://gbfs.citibikenyc.com/gbfs/en/station_status.json";
		String statusStr=HttpUtil.get(statusUrl);
		JSONObject obj=JSON.parseObject(statusStr);
		JSONObject data=obj.getJSONObject("data");
		JSONArray stations=data.getJSONArray("stations");
		// Ҫ��ʵ�������������JSON�ַ����е�key����һ��
		List<StationStatusDO> list = 
				JSON.parseObject(stations.toString(),
						new TypeReference<List<StationStatusDO>>(){});
		
		StationDAO dao=new StationDAO();
		dao.batchSaveStatus(list);
		
		/*for(StationStatusDO ssDO:list){
			System.out.println(ssDO);
		}*/
		
//		List<StationStatusDO> list2=new ArrayList<StationStatusDO>();
//		Iterator<Object> it=stations.iterator();
//		while(it.hasNext()){
//			JSONObject jObj=(JSONObject)it.next();
//			Integer id=jObj.getInteger("station_id");
//			Integer nba=jObj.getInteger("num_bikes_available");
//			StationStatusDO ssDO2=new StationStatusDO();
//			ssDO2.setNum_bikes_available(nba);
//			ssDO2.setStation_id(id);
//			list2.add(ssDO2);
//			System.out.println("id="+id+",nba="+nba);
//		}
	}

}




