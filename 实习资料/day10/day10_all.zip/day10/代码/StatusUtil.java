package cn.tedu.nybike.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class StatusUtil {
	
	/**
	 * ��ȡstatus�����ļ�����json��ʽ����
	 * ������csv���ݵķ���
	 * @param inputPath status�ļ�·��
	 * @param dirPath ����ļ�·��
	 * @param regex �����ļ������ݷָ���
	 */
	public static void parseStatus(String inputPath, String dirPath, String regex){
		
		int inCount=0;
		int outCount=0;
		
		File inputFile=new File(inputPath);
		File outputFile=new File(dirPath);
		String headLine="data_timestamp,station_id,num_bikes_available,num_bikes_disabled,num_docks_available,num_docks_disabled,is_installed,is_renting,is_returning,last_reported";//9���ֶ�
		String[] fields={"station_id","num_bikes_available","num_bikes_disabled","num_docks_available","num_docks_disabled","is_installed","is_renting","is_returning","last_reported"};
		
		try(BufferedReader br=new BufferedReader(new FileReader(inputFile));
				BufferedWriter bw=new BufferedWriter(new FileWriter(outputFile))){
			// �����ͷ��
			bw.write(headLine);
			bw.newLine();
			outCount++;
			// ��ȡһ������
			String line=br.readLine();
			inCount++;
			
			while(line!=null){
				// JSON����
				JSONObject lineObj=JSON.parseObject(line);
				long data_timestamp=lineObj.getLongValue("last_updated")*1000;
				JSONArray array=lineObj.getJSONObject("data").getJSONArray("stations");
				for(Object obj:array){
					JSONObject jsonObj=(JSONObject)obj;
					StringBuffer sb=new StringBuffer();
					sb.append(data_timestamp).append(regex);
					for(int i=0;i<fields.length;i++){
						sb.append(jsonObj.get(fields[i]));
						if(fields[i].equals("last_reported")){
							sb.append("000");
						}
						if(i!=fields.length-1){
							sb.append(regex);
						}
					}
					bw.write(sb.toString());
					outCount++;
					bw.newLine();
				}
				line=br.readLine();
				inCount++;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("����ȡ��"+inCount);
		System.out.println("��д����"+outCount);
	}

	public static void main(String[] args) {
		String inputPath="C:\\Users\\admin\\Desktop\\status_915.txt";
		String dirPath="C:\\Users\\admin\\Desktop\\status_915.csv";
		String regex=",";
		StatusUtil.parseStatus(inputPath, dirPath, regex);
	}

}






