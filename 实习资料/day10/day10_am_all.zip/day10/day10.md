###17 使用Hive进行数据分析

示例1：6月1日骑行者的男女比例

大数据平台：

- hive上建表，来保存分析结果

- hive上分析数据，将结果保存到目标表中

- 进行必要的配置，保证JavaWeb程序可以顺利访问Hive

	首先需要配置hive的配置文件 hive-site.xml

		cd /opt/hive-2.3.5/conf
		vim hive-site.xml

		在<configuration></configuration>标签中添加以下内容

		<property>
			<name>hive.server2.thrift.port</name>
			<value>10000</value>
		</property>
		<property>
			<name>hive.server2.thrift.client.user</name>
			<value>root</value>
		</property>
		<property>
			<name>hive.server2.thrift.client.password</name>
			<value>root</value>
		</property>

	然后配置Hadoop的配置文件 core-site.xml

		cd /opt/hadoop-2.6.5/etc/hadoop
		vim core-site.xml

	在<configuration></configuration>标签中添加以下内容

		<property>
			<name>hadoop.proxyuser.root.hosts</name>
			<value>*</value>
		</property>
		<property>
			<name>hadoop.proxyuser.root.groups</name>
			<value>*</value>
		</property>

	配置成功后，注意要关闭并重新启动hadoop



JavaWeb项目：

- 项目中需要引入所需的jar包

		<!-- jdbc访问hive所需jar包 -->
		<dependency>
		  <groupId>org.apache.hive</groupId>
		  <artifactId>hive-jdbc</artifactId>
		  <version>2.3.4</version>
		</dependency>

		<!-- hadoop基础jar包 -->
		<dependency>
		  <groupId>org.apache.hadoop</groupId>
		  <artifactId>hadoop-common</artifactId>
		  <version>2.6.5</version>
		</dependency>

- 基于JDBC访问Hive，从目标表中查询分析结果（XXXDO）

	在`nybike`中开发`cn.tedu.nybike.util.HiveDBUtil`，代码如下：

		public class HiveDBUtil {
	                        
			private static String url="jdbc:hive2://192.168.56.101:10000/nybikedb";
			private static String user="root";
			private static String password="root";
			
			static{// 静态代码块/静态初始化器
				try {
					Class.forName("org.apache.hive.jdbc.HiveDriver");
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
			
			/**
			 * 获取hive连接的方法
			 * @return 连接对象
			 * @throws SQLException 
			 */
			public static Connection getHiveConn() throws SQLException{
				return DriverManager.getConnection(
						url, user, password);
			}
			
			public static void main(String[] args) throws SQLException {
				Connection conn=HiveDBUtil.getHiveConn();
				System.out.println(conn);
			}
		
		}

	在`nybike`中开发`cn.tedu.nybike.pojo.GenderCountDO`，用于封装查询到的GenderCount数据，代码如下：

		public class GenderCountDO {
			
			private Date startDate;
			private Integer gender;
			private Integer num;
			
			// 无参构造器/get/set/toString()
			
		}

	在`nybike`中开发`cn.tedu.nybike.dao.HiveDAO`，在类中添加查询GenderCount的方法，代码如下：

		public class HiveDAO {
			// 解耦的基本原则：JDBC的特殊对象只能在DAO中
		
			/**
			 * 查询所有GenderCount的方法
			 * @return 封装了GenderCount的集合 或 空集合
			 */
			public List<GenderCountDO> listGenderCount(){
				List<GenderCountDO> list=new ArrayList<>();
				String sql="select * from tb_gender_count";
				try(Connection conn=HiveDBUtil.getHiveConn();
						PreparedStatement ps=conn.prepareStatement(sql)){
					ResultSet rs=ps.executeQuery();
					while(rs.next()){
						GenderCountDO gc=new GenderCountDO();
						gc.setStartDate(rs.getDate("start_date"));
						gc.setGender(rs.getInt("gender"));
						gc.setNum(rs.getInt("num"));
						
						list.add(gc);
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
				return list;
			}
		}


	在`nybike`的`src/test/java`中开发`cn.tedu.nybike.dao.HiveDAOTests`，在类中添加测试方法，并导入`org.junit.Test`，代码如下：

		public class HiveDAOTests {
			HiveDAO dao=new HiveDAO();
			@Test
			public void listGenderCount(){
				List<GenderCountDO> list=dao.listGenderCount();
				for(GenderCountDO gc:list){
					System.out.println(gc);
				}
			}
		}


- 将XXXDO(以一条数据为单位，理论上同时包含X轴的值和Y轴的值)转变成XXXVO(X轴数据的集合+Y轴数据的集合)
	
	在`nybike`中开发`cn.tedu.nybike.pojo.GCItem`，代码如下：

		public class GCItem {
			private String name; // 性别
			private Integer value; // 数量
			
			// 无参构造器/get/set/toString()
		}

	在`nybike`中开发`cn.tedu.nybike.pojo.GenderCountVO`，代码如下：

		public class GenderCountVO {
			
			private List<GCItem> data;
		
			// 无参构造器/get/set/toString()
		
		}


	在`nybike`中开发`cn.tedu.nybike.service.TripService`，代码如下：

		public class TripService {
			
			private HiveDAO dao=new HiveDAO();
			
			public GenderCountVO findGenderCount(){
				// 创建VO对象
				GenderCountVO vo=new GenderCountVO();
				
				// 调用dao方法查询数据
				List<GenderCountDO> list=dao.listGenderCount();
				// 创建集合用于封装VO中的item
				List<GCItem> data=new ArrayList<GCItem>(list.size());
				// 遍历查询到的数据
				for(GenderCountDO gc:list){
					// 创建item对象，封装每一项的数据
					GCItem item=new GCItem();
					item.setValue(gc.getNum());
					// 将0-2的性别编号转成对应的名称
					String name=gc.getGender()==0?"未知":gc.getGender()==1?"男":"女";
					item.setName(name);
					// 将item添加到集合中
					data.add(item);
				}
				// 将集合添加到vo对象中
				vo.setData(data);
				
				return vo;
			}
		
		}

	在`nybike`的`src/test/java`中开发`cn.tedu.nybike.service.TripServiceTests`，在类中添加测试方法，并导入`org.junit.Test`，代码如下

		public class TripServiceTests {
			
			TripService service=new TripService();
			
			@Test
			public void findGenderCount(){
				GenderCountVO vo=service.findGenderCount();
				System.out.println(vo);
				String jsonStr=JSON.toJSONString(vo);
				System.out.println(jsonStr);
			}
		
		}
####-------------- day10开始 --------------
- 将XXXVO转成JSON格式，发送给浏览器

	在`nybike`中开发`cn.tedu.nybike.web.GenderCountServlet`，调用`TripService`的方法，代码如下：

		public class GenderCountServlet extends HttpServlet {
			private static final long serialVersionUID = 1L;
			
			TripService service=new TripService();
		
			protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				// 调用Service获取VO对象
				GenderCountVO vo=service.findGenderCount();
				// 调用FastJSON方法将vo转成JSON字符串
				String jsonStr=JSON.toJSONString(vo);
				// 通知浏览器，本次返回数据的类型是json
				response.setContentType(
						"application/json;charset=utf-8");
				// 将数据返回给浏览器
				response.getWriter().write(jsonStr);
			}
		
		}

前端界面：

- 发送AJAX请求分析的结果
- 初始化Echarts图表，添加数据
- 在页面上显示数据的图表

	在`nybike`的`Deployed Resources/webapp`下开发`gender_count.html`，通过AJAX请求数据，初始化Echarts图表，代码如下：

		<!DOCTYPE html>
		<html>
		<head>
		<meta charset="UTF-8">
		<title>骑行男女数量及占比</title>
		<script type="text/javascript" 
			src="js/echarts.min.js"></script>
		<script type="text/javascript" 
			src="js/jquery-1.11.0.min.js"></script>
		</head>
		<body>
		
			<div id="div1" style='height: 400px;width: 600px' ></div>
		
		</body>
		<script type="text/javascript">
			// 声明服务器GenderCountServlet对应的url
			var url="http://localhost:8080/nybike/gender_count";
			// 通过jQuery发送AJAX请求
			$.get(url,function(result){
				// 从响应数据中获取饼图展示数据
				var pieData = result.data;
				// 声明页面左侧工具栏使用的数据的数组
				var legendArr = [];
				// 循环将数据添加到legendArr中
				for(var index in pieData){
					legendArr.push(pieData[index].name);
				}
				// 声明myChart对象，绑定页面的div
				var myChart = echarts.init(
						document.getElementById('div1'));
				// 声明图表配置对象
				option = {
					    title : {
					        text: '骑行男女数量及占比',
					        subtext: '20190601',
					        x:'center'
					    },
					    tooltip : {
					        trigger: 'item',
					        formatter: "{a} <br/>{b} : {c} ({d}%)"
					    },
					    legend: {
					        orient: 'vertical',
					        left: 'left',
					        data: legendArr
					    },
					    series : [
					        {
					            name: '骑行者性别',
					            type: 'pie',
					            radius : '55%',
					            center: ['50%', '60%'],
					            data:pieData,
					            itemStyle: {
					                emphasis: {
					                    shadowBlur: 10,
					                    shadowOffsetX: 0,
					                    shadowColor: 'rgba(0, 0, 0, 0.5)'
					                }
					            }
					        }
					    ]
				};
				// 使用刚指定的配置项和数据显示图表。
		        myChart.setOption(option);
			});
		</script>
		</html>