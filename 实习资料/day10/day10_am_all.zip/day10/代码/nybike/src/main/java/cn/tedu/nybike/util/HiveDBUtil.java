package cn.tedu.nybike.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class HiveDBUtil {
	                        
	private static String url="jdbc:hive2://192.168.56.101:10000/nybikedb";
	private static String user="root";
	private static String password="root";
	
	static{// ��̬�����/��̬��ʼ����
		try {
			Class.forName("org.apache.hive.jdbc.HiveDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * ��ȡhive���ӵķ���
	 * @return ���Ӷ���
	 * @throws SQLException 
	 */
	public static Connection getHiveConn() throws SQLException{
		return DriverManager.getConnection(
				url, user, password);
	}
	
	public static void main(String[] args) throws SQLException {
		Connection conn=HiveDBUtil.getHiveConn();
		System.out.println(conn);
	}

}




