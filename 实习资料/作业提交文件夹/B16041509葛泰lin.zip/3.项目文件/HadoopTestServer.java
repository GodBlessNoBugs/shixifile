package cn.tedu.nybike.web;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;



import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Servlet implementation class HadoopTest
 */
public class HadoopTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Map<String,Integer> tempMap = new HashMap<String,Integer>();

		List<String> strlist= new ArrayList<String>();

		

		

		

		String reslt = "C:/Users/TEDU/Desktop/day3/nybike/src/main/resources/part-r-00000";//Ĭ������ļ�

		try {

		

		
			FileInputStream inStream = new FileInputStream(reslt);
			

			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inStream,"utf-8"));

			//URI uri = file.toUri();//�õ�����ļ�·��



			String data = null;

			while ((data = bufferedReader.readLine()) != null ) {

				strlist.add(data);

				int bt = data.lastIndexOf('\t');//Hadoop������ļ�ÿһ��Ϊword   times����ʽ�����ʺʹ���֮��Ϊһ��tab����\t��

				tempMap.put(data.substring(0,bt), Integer.parseInt(data.substring(bt+1,data.length())));

				//System.out.println(data.substring(0,bt) + "������" + Integer.parseInt(data.substring(bt+1,data.length())) + "��");

				//response.getOutputStream().println(data);//������ļ�д���û���ҳ

			}

			//response.getOutputStream().println("success.");//������ļ�д���û���ҳ

 

			inStream.close();

		

			tempMap = sortByValue(tempMap);//����Map�����ִ����Ӵ�С����

		

			Map<String,Integer> resultMap = new HashMap<String,Integer>();

			Set<String> keys = tempMap.keySet();

			int size = 25;//�ҵ�ǰ25��

			for(String key : keys)

				{

				if(size==0)

					break;

				resultMap.put(key, tempMap.get(key));

				size--;

				}

			

	

			Gson gson = new Gson();

			String json  = gson.toJson(resultMap);//�����ת��Ϊjson�ַ���

			request.getSession().setAttribute("json", json);//����session��

			response.getWriter().write(json);//����json�ַ���

		} catch (Exception e) {

			System.err.println(e.getMessage());

			e.printStackTrace();

		}

	}

	public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map) {

        List<Map.Entry<K, V>> list = new LinkedList<>(map.entrySet());

        Collections.sort(list, new Comparator<Map.Entry<K, V>>() {

            @Override

            public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2) {

                return (o2.getValue()).compareTo(o1.getValue());//�Ӵ�С

            }

        });

 

        Map<K, V> result = new LinkedHashMap<>();

        for (Map.Entry<K, V> entry : list) {

            result.put(entry.getKey(), entry.getValue());

        }

        return result;

    }



}
