### 1.下载<简爱>英文

###  2.上传虚拟机,上传hadoop

###  3.调用程序统计词频

### 4.下载结果

### 5.将结果文件放到nybike项目中

### 6.创建servelt类

1. 读取结果文件
2. 将前25的数据以json格式放到request中

### 7.firstEchars.Html 中ajax获取数据,设置到myChart中

