    
    var myChart2 = echarts.init(document.getElementById('main2'));  

    option2 = {
        title: {
            text: '纵横小说排行榜'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data:['日点击榜','周点击榜','月点击榜','总点击榜']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: ["元尊","点道为止","圣武星辰","一剑独尊"]
        },
        yAxis: {
            type: 'value'
        },
        series: [{
            name: '日点击榜',
            type:'line',
            data: [14661, 13641, 10293, 7471]
        },{
            name: '周点击榜',
            type:'line',
            data: [146621, 136241, 102393, 107471]
        },{
            name: '月点击榜',
            type:'line',
            data: [2146621, 1136241, 1102393, 1107471]
        },{
            name: '总点击榜',
            type:'line',
            data: [9146621, 8136241, 7102393, 6107471]
        }
        ]
    };

    // 使用刚指定的配置项和数据显示图表。

    myChart2.setOption(option2);