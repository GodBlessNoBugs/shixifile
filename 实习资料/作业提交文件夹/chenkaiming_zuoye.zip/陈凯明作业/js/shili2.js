var myChart1 = echarts.init(document.getElementById('main1'));
var option1 = {
        title: {
            text: '纵横小说排行榜'
        },
        tooltip: {},
        legend: {
            data:['日点击榜','周点击榜','月点击榜','总点击榜']
        },
        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        xAxis: {
            data: []
        },
        yAxis: {},
        series: [
            {   name: '日点击榜',
                type: 'bar',
                data: []
            },
            {   name: '周点击榜',
                type: 'bar',
                data: []
            },
            {   name: '月点击榜',
                type: 'bar',
                data: []
            },
            {   name: '总点击榜',
                type: 'bar',
                data: []
            }
        ]
    };

//异步加载数据
    var dataArr=["data/data.json"];
    var dataUrl=dataArr[1];
$.get(dataArr).done(function (data) {
    // 填入数据
    myChart1.setOption({
        xAxis: {
            data: data.categories
        },
        series: [{
            // 根据名字对应到相应的系列
            name: '日点击榜',
            data: data.data.d1
        },{
            // 根据名字对应到相应的系列
            name: '周点击榜',
            data: data.data.d2
        },{
            // 根据名字对应到相应的系列
            name: '月点击榜',
            data: data.data.d3
        },{
            // 根据名字对应到相应的系列
            name: '总点击榜',
            data: data.data.d4
        }]
    });
});

myChart1.setOption(option1);