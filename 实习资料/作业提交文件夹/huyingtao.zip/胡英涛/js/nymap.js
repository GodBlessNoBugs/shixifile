function StationDetail(){
	
}


function addMarkerInfoWindow(marker,id){
	//在`addMarkerInfoWindow()`方法中，使用参数`id`从`detialMap`中查询对应的`StationDetial`对象，
	//将获取到的数据拼接生成`infoWindow`的内容
	var sDetail=detailMap.get(id);
	
	var sContent ="<div class='mapbox-content'>"+
	"<div class='mapbox-content-top'>"+
	"<span class='window_lastUpdate'> 0 ms ago </span>"+ 
	"<span class='window_info_button'></span>"+
"</div>"+
"<div class='mapbox-content-header'>"+
	"<h1 class='mapbox-content-header-stationName'>"+sDetail.name+"</h1>"+
"</div>"+
"<div class='mapbox-content-detail'>"+
	"<div class='mapbox-content-detail-bikes-available'>"+
		"<span class='mapbox-content-detail-bikes-available-val'> "+sDetail.nba+"</span>"+
		"<span class='mapbox-content-detail-bikes-available-lbl'>Bikes</span>"+
	"</div>"+
	"<div class='mapbox-content-detail-docks-available'>"+
		"<span class='mapbox-content-detail-docks-available-val'>"+sDetail.nda+"</span>"+
		"<span class='mapbox-content-detail-docks-available-lbl'>Docks</span>"+
	"</div>"+
"</div>"+
"<div class='mapbox-content-footer'>"+
	"<span class='mapbox-content-footer-shortName'>"+sDetail.shortName+"</span>"+
"</div>"+
"</div>";
	var infoWindow = new BMap.InfoWindow(sContent);  // 创建信息窗口对象
	marker.addEventListener("click", function(){          
		   this.openInfoWindow(infoWindow);
		    
		});
} 


function switchIcon(isBigIcon){
	 //isBigIcon表示当前应该使用的图标
	 //alert("缩放级别改变");
	 for(var index in markerArr){
		 var iconSize;
		 var anchorSize;
		 //imageUrl的转换,先获得原先的图标
		 var imageUrl=markerArr[index].getIcon().imageUrl;
		 //var bikeLevel=imageUrl.substring();
		 if(isBigIcon==true){
			 //s->b
			imageUrl=imageUrl.replace(/s/,"b");
			anchorSize=bigIconSize;
			iconSize=bigAnchorSize;
		 }
		 
		 if(isBigIcon==false){
			 //s->b
			imageUrl=imageUrl.replace(/b/,"s");
			anchorSize=smallIconSize;
			iconSize=smallAnchorSize;
		 }
		 
		 
		 //创建新的Icon
		 var opts={
	    		 anchor:new BMap.Size(20,50),
	     		 imageSize:iconSize
	     }; 
	    // 创建标注对象并添加到地图   
	    var myIcon=new BMap.Icon(imageUrl,iconSize,opts);
	    //调用marker的setIcon方法，设置新的Icon
	    markerArr[index].setIcon(myIcon);
		 
	 }
	 
 }


function getBikeLevel(nba,nda){
	if(nba==0||(nba+nda)==0){
		 return 0;
	}
	if(nba<5){
		return 1;
	}
	//可用车指数
	var abi=nba/(nba+nda);
	if(abi<0.5){
		return 2;
	}
	if(abi>=0.5&&abi<1){
		return 3;
	}
	if(abi=1){
		return 4;
	}
	
}

function addInformation(marker){
	var infoWindow = new BMap.InfoWindow(sContent);  // 创建信息窗口对象    
	map.openInfoWindow(infoWindow, map.getCenter());      // 打开信息窗口
}


//point marker在地图上的位置
//imgUrl Icon 使用的图片
//iconSize Icon的大小,即可视区域的大小
//anchorSize point相对于Icon左上角的偏移量

function addMarker(point,imgUrl,iconSize,anchorSize,id){  // 创建图标对象   
     /*var imgUrl="img/bi_0.png";
     var iconSize=new BMap.Size(41,50);*/
     var opts={
    		 anchor:anchorSize,
     		 imageSize:iconSize
     }; 
    // 创建标注对象并添加到地图   
    var myIcon=new BMap.Icon(imgUrl,iconSize,opts);
    var marker = new BMap.Marker(point, {icon: myIcon}); 
    markerArr.push(marker);
    addMarkerInfoWindow(marker,id);
    map.addOverlay(marker);
}  













