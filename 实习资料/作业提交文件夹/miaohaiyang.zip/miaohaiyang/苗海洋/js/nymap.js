//添加一个标注的方法
//point marker在地图上的经纬度
//imgUrl Icon使用的图片的url
//iconSize Icon 的大小，即可视区域大小
//anchorSize point 相对于Icon左上角的量
function switchIcon(isBigIcon){
	for(var index in markerArr){
		var imageUrl=markerArr[index].getIcon().imageUrl;
		var iconSize;
		var anchorSize;
		if(isBigIcon==true){
			imageUrl=imageUrl.replace(/s/,"b");
			iconSize=bigIconSize;
			anchorSize=bigAnchorSize;
		}
		if(isBigIcon==false){
			imageUrl=imageUrl.replace(/b/,"s");
			iconSize=smallIconSize;
			anchorSize=smallAnchorSize;
		}
		//创建新的Icon
		var opts={
				anchor:anchorSize,
				imageSize:iconSize
		};
		var myIcon=new BMap.Icon(imageUrl,iconSize,opts);
		//调用Marker的setIcon方法，设置新的Icon
		markerArr[index].setIcon(myIcon);
		
		
	}
}




function getBikeLevel(nba,nda){
	 
	  if(nba==0||(nba+nda)==0){
		  return 0;
	  }
	  if(nba<5){
		  return 1;
	  }
	  var abi=nba/(nba+nda);
	  if(abi<0.5){
		  return 2;
	  }
	  if(abi>=0.5&&abi<1){
		  return 3;
	  }
	  if(abi==1){
		  return 4;
	  }
}

//

function StationDetail(){}

function addMarkerInfoWindow(marker,id){
	    
	var sDetail=detailMap.get(id);
	
	var sContent="<div class='mapbox-content'>"+
		"<div class='mapbox-content-top'>"+
			"<span class='window_lastUpdate'> 0 ms ago </span> <span"+
				"class='window_info_button'></span>"+
		"</div>"+
		"<div class='mapbox-content-header'>"+
			"<h1 class='mapbox-content-header-stationName'>"+sDetail.name+"</h1>"+
		"</div>"+
		"<div class='mapbox-content-detail'>"+
			"<div class='mapbox-content-detail-bikes-available'>"+
				"<span class='mapbox-content-detail-bikes-available-val'> "+sDetail.nba+ "</span>"+
				"<span class='mapbox-content-detail-bikes-available-lbl'>Bikes</span>"+
			"</div>"+
			"<div class='mapbox-content-detail-docks-available'>"+
				"<span class='mapbox-content-detail-docks-available-val'> "+sDetail.nda+" </span> <span"+
					"class='mapbox-content-detail-docks-available-lbl'>Docks</span>"+
			"</div>"+
		"</div>"+
		"<div class='mapbox-content-footer'>"+
			"<span class='mapbox-content-footer-shortName'> Bike station:"+
				+sDetail.shortName+" </span>"+
		"</div>"+
	"</div>";
    var infoWindow=new BMap.InfoWindow(sContent);
    
    marker.addEventListener("click", function(){          
		this.openInfoWindow(infoWindow,point); //开启信息窗口
		});
}






function addMarker(point,imgUrl,iconSize,anchorSize,id){  // 创建图标对象   
	
	
	var opts={  
		    anchor: anchorSize,
            imageSize: iconSize
            };
    var myIcon = new BMap.Icon(imgUrl,iconSize,opts);  
           
        
    // 创建标注对象并添加到地图   
    var marker = new BMap.Marker(point, {icon: myIcon});  
    //将maker对象添加到marker数组中
    markerArr.push(marker);
    
    //调用方法为marker添加信息窗
    addMarkerInfoWindow(marker,id);
    map.addOverlay(marker);  
   
} 
 























