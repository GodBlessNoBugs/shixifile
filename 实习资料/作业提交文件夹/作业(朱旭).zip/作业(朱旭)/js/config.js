var achobigSize = new BMap.Size(21, 50);
var iconbigSize = new BMap.Size(41, 50);
var achosmallSize = new BMap.Size(10, 25);
var iconsmallSize = new BMap.Size(20, 25);
var achovsmallSize = new BMap.Size(5, 10);
var iconvsmallSize = new BMap.Size(5, 10);

var URL = {
    station_status: "https://gbfs.citibikenyc.com/gbfs/en/station_status.json",
    stationInfo: "https://gbfs.citibikenyc.com/gbfs/en/station_information.json",
    station_status_back: "/nybike/StationStatusServlet",
    station_Info_back: "/nybike/StationInfoServlet"
}