import requests
from lxml import etree
import xlwt

def getDetailByPage(page_links):
    sheetname1 = xlwt.Workbook()
    sheetname = sheetname1.add_sheet(place+"景点", cell_overwrite_ok=True)
    sheetname.write(0, 0, "景点")
    sheetname.write(0, 1, "城市")
    sheetname.write(0, 2, "票价")
    sheetname.write(0, 3, "月销量")
    sheetname.write(0, 4, "热度")
    sheetname.write(0, 5, "地址")
    sheetname.write(0, 6, "标语")
    # sheetname1.save(place + ".xls")
    sheetname1.save(place + ".csv")
    name=[]
    city=[]
    price=[]
    sold=[]
    hot=[]
    address=[]
    logo=[]
    for url in page_links:
        content = requests.get(url)
        con = etree.HTML(content.text)
        name1 = con.xpath("//a[@class='name']/text()")
        city1=con.xpath("//span[@class='area']/a/text()")
        price1=con.xpath("//span[@class='sight_item_price']/em/text()")
        sold1 = con.xpath("//span[@class='hot_num']/text()")
        hot1 = con.xpath("//span[@class='product_star_level']//span/text()")
        address1=con.xpath("//p[@class='address color999']/span/text()")
        logo1=con.xpath("//div[@class='intro color999']/text()")
        for i in name1:
            name.append(i)
        for j in city1:
            city.append(j)
        for k in price1:
            price.append(k)
        for l in sold1:
            sold.append(l)
        for m in hot1:
            hot.append(m)
        for n in address1:
            address.append(n)
        for o in logo1:
            logo.append(o)
    a=""
    index=len(name)
    for name1 in name:
        print(name1)
        sheetname.write(index,0, name1)
        index=index-1
    # sheetname1.save(place + ".xls")

    index1=len(city)
    for city1 in city:
        city1=city1+a
        city1=city1[6:]
        print(city1)
        sheetname.write(index1,1, city1)
        index1=index1-1
    index2=len(name)
    for price1 in price:
        print(price1)
        sheetname.write(index2,2, price1)
        index2=index2-1
    index3=len(name)
    for sold1 in sold:
        print(sold1)
        sheetname.write(index3,3, sold1)
        index3=index3-1
    index4=len(hot)
    for hot1 in hot:
        hot1=hot1+a
        hot1=hot1[3:]
        print(hot1)
        sheetname.write(index4,4, hot1)
        index4=index4-1
    index5=len(address)
    for address1 in address:
        address1=address1[3:]
        print(address1)
        sheetname.write(index5,5, address1)
        index5=index5-1

    index6=len(logo)
    for logo1 in logo:
        print(logo1)
        sheetname.write(index6,6, logo1)
        index6=index6-1
    sheetname1.save(place + ".xls")


if __name__ == '__main__':
    place=input("请输入您想要去的城市")
    url="https://piao.qunar.com/ticket/list.htm?keyword="+place+"&region=&from=mpl_search_suggest"
    data = requests.get(url)
    tree = etree.HTML(data.text)
    allpage=tree.xpath("//div[@class='pager']/a[8]/text()")
    page_links = []
    page_links.append(url)
    allpage="".join(allpage)
    print(allpage)
    allpage=int(allpage)
    print(allpage)
    for i in range(2,12):
        url="https://piao.qunar.com/ticket/list.htm?keyword="+place+"&region=&from=mpl_search_suggest&page="+str(i)
        page_links.append(url)
    print(page_links)
    getDetailByPage(page_links)
  #景点名称','级别','所在区域','起步价','销售量','热度','地址','标语','详情网址


