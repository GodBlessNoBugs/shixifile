import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class GetData {
    public static void main(String[] args) throws IOException {

        File xlsFile = new File("E:\\beijing.xls");
        /**
         * 这里根据不同的excel类型
         * 可以选取不同的处理类：
         *          1.XSSFWorkbook
         *          2.HSSFWorkbook
         */
        // 获得工作簿
        HSSFWorkbook workbook = new HSSFWorkbook(new FileInputStream(xlsFile));

        // 获得工作表
        HSSFSheet sheet = workbook.getSheetAt(0);
        String cell_1="";
        String cell_3="";
        int rows = sheet.getPhysicalNumberOfRows();
        String name[]=new String[rows];
        String price[]=new String[rows];
        for (int i = 0; i < rows; i++) {
            // 获取第i行数据
            HSSFRow sheetRow = sheet.getRow(i);
            // 获取第0格数据
            HSSFCell cell = sheetRow.getCell(0);
            // 调用toString方法获取内容
            cell_1 = cell.toString();
           // System.out.println("\""+cell_1+"\""+",");
            // 获取第0格数据
            HSSFCell cell2 = sheetRow.getCell(3);
            // 调用toString方法获取内容
            cell_3 = cell2.toString();
           // System.out.println(cell_3+",");
            name[i]=cell_1;
            System.out.println("{value:"+cell_3+",name:"+"\""+cell_1+"\""+"},");
            price[i]=cell_3;
        }

/*        String sold[]=new String[rows];
        for (int j = 0; j < rows; j++) {
            // 获取第i行数据
            HSSFRow sheetRow = sheet.getRow(j);
            // 获取第0格数据
            HSSFCell cell = sheetRow.getCell(3);
            // 调用toString方法获取内容
            cell_1 = cell.toString();
            System.out.println(cell_1+",");
            name[j]=cell_1;
        }*/
        for (int j = 0; j < rows; j++) {
            System.out.println(price[j]+",");
        }

        for (int x = 0; x < rows; x++) {
            System.out.println("\""+name[x]+"\""+",");
        }




    }
}
