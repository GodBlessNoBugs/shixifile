CREATE TABLE tb_frequency_man(
station_id int,
num int,
lon DOUBLE,
lat DOUBLE
);
insert overwrite table tb_frequency_man 
select start_station_id,count(*),collect_set(start_station_longitude)[0],collect_set (start_station_latitude)[0] from tb_trip_all where gender=1 group by start_station_id;


CREATE TABLE tb_frequency_woman(
station_id int,
num int,
lon DOUBLE,
lat DOUBLE
    
);

insert overwrite table tb_frequency_woman 
select start_station_id,count(*),collect_set(start_station_longitude)[0],collect_set (start_station_latitude)[0] from tb_trip_all where gender=2 group by start_station_id;
-------------------------------------------
区域男女活动频率  id+坐标+频率  （1 男 2 女） 热点图