CREATE TABLE tb_age_num(
    agetype string,
    num int
);
create table tb_trip_all(
tripduration int,
starttime string,
stoptime string,
start_station_id int,
start_station_name string,
start_station_latitude double,
start_station_longitude double,
end_station_id int,
end_station_name string,
end_station_latitude double,
end_station_longitude double,
bikeid int,
usertype string,
birth_year int,
gender int
)ROW FORMAT DELIMITED FIELDS TERMINATED BY ',';

load data inpath 'hdfs://master:8020/201906-2.csv' 
overwrite into table tb_trip_all;
select count(*) from tb_trip_all where birth_year>2001;
select count(*) from tb_trip_all where birth_year<=2001 and birth_year>=1974;
select count(*) from tb_trip_all where birth_year<1974;

insert into tb_age_num VALUES ('teenager',3341),('youth',1455385),('middle-aged',666644);