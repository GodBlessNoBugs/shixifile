

create table tb_trip_all(
tripduration int,
starttime string,
stoptime string,
start_station_id int,
start_station_name string,
start_station_latitude double,
start_station_longitude double,
end_station_id int,
end_station_name string,
end_station_latitude double,
end_station_longitude double,
bikeid int,
usertype string,
birth_year int,
gender int
)ROW FORMAT DELIMITED FIELDS TERMINATED BY ',';





load data inpath 'hdfs://master:8020/201906-2.csv' 
overwrite into table tb_trip_all;


create table tb_passenger_num(
    day string,
    num int
);

insert overwrite table tb_passenger_num 
SELECT substr(starttime,0,10),COUNT(1)  from tb_trip_all GROUP BY substr(starttime,0,10) ;





select substr(starttime,0,10) as time,count(*) from tb_trip_all group by substr(starttime,0,10) order by time;
