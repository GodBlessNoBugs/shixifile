CREATE TABLE station_frequency(
station_id int,
num int,
lon DOUBLE,
lat DOUBLE
);

insert overwrite table station_frequency 
select start_station_id,count(*),collect_set(start_station_longitude)[0],collect_set (start_station_latitude)[0] from tb_trip_all group by start_station_id;

